---
layout: page
title: Web UI
hide_hero: true
show_sidebar: false
menubar: docs-menu
---

# Web UI

With the release of `v0.14.1` Moov Fed contains a builtin Web UI that's hosted from the Go binary / Docker image.

<table>
<tr style="align:center;">
<td><img src="../images/ach-search.png" /></td>
<td><img src="../images/wire-search.png" /></td>
</tr>
</table>
