# FedWire directory

* Data: [fpddir.txt](../data/fpddir.txt)
* JSON Data Example: [fpddir.json](../data/fpddir.json)
* Format: [fpddir_format.md](fpddir_FORMAT.md)
* Source: [Federal Reserve Bank Services](https://frbservices.org/)

The effective date of this Fedwire directory is Dec 4th, 2018. These data files are no longer published on the [FRBServices](https://frbservices.org/) website.