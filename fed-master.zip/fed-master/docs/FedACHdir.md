# FedACH directory

* Data: [FedACHdir.txt](../data/FedACHdir.txt)
* JSON Data Example: [fedachdir.json](../data/fedachdir.json)
* Format: [FEDACHDIR_FORMAT.MD](FEDACHDIR_FORMAT.MD)
* Source: [Federal Reserve Bank Services](https://frbservices.org/)

The effective date of this FedACH directory is Dec 4, 2018. These data files are no longer published on the [FRBServices](https://frbservices.org/) website.
