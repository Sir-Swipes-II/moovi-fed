# AchLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** | Street Address | [optional] 
**City** | **string** | City | [optional] 
**State** | **string** | State | [optional] 
**PostalCode** | **string** | Postal Code | [optional] 
**PostalExtension** | **string** | Postal Code Extension | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


